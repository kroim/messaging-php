<?php
$themeName = 'WoWonder';

$themeFolder = 'wowonder';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:wowondersocial@gmail.com';

$themeVirsion = '1.5.6';

$themeImg = $themeFolder . '/themeLogo.png';
?>