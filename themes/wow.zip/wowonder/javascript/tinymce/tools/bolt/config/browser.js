configure({
    configs: [
        '../../../js/tinymce/plugins/wordcount/config/bolt/browser.js',
        '../../../js/tinymce/plugins/media/config/bolt/browser.js',
        '../../../js/tinymce/plugins/lists/config/bolt/browser.js',
        '../../../js/tinymce/themes/inlite/config/bolt/browser.js',
        '../../../js/tinymce/themes/modern/config/bolt/browser.js'
    ]
});